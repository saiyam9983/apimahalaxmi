const url =
  "mongodb+srv://Saiyam1999:sam1999@cluster0.2l0ouiw.mongodb.net/?retryWrites=true&w=majority";
export default url;
